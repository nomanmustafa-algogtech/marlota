<!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">


                <div class="content">

                    <!-- Start Content-->
                    <div class="container-fluid">
                            
                        
                            <!-- start page title -->
                            <div class="row">
                                <div class="col-12">
                                    <div class="page-title-box">
                                        <h4 class="page-title">All Orders</h4>
                                        <!--<div class="page-title-right">-->
                                        <!--    <button type="button" class="btn btn-success waves-effect waves-light" onclick="window.location.href='<?=base_url('admin/products/add_new');?>'">-->
                                        <!--           <span class="btn-label"><i class="mdi mdi-account-plus"></i></span> Add Product-->
                                        <!--    </button>-->
                                        <!--</div>-->
                                    </div>
                                   
                                </div>
                            </div>
                            
                            <div class="row">
                       
                                <div class="col-12">
                                    <?=$this->CI->flash_message();?><br>
                                    <form action="" method="POST" style="margin-bottom: 10px;">
                                        <div class="row">
                                            <div class="col-sm-3 col-12">
                                                <input type="number" placeholder="Order #" class="form-control" name="order_id" value="<?php if(isset($_POST['order_id'])){ echo $_POST['order_id']; } ?>" />
                                            </div>
                                            <div class="col-sm-2 col-12" >
                                                <input type="date" class="form-control" name="from_date" value="<?php if(isset($_POST['from_date'])){ echo $_POST['from_date']; } ?>" />
                                            </div>
                                            <div class="col-sm-2 col-12" >
                                                <input type="date" class="form-control" name="to_date" value="<?php if(isset($_POST['to_date'])){ echo $_POST['to_date']; } ?>" />
                                            </div>
                                            <div class="col-sm-5 col-12">
                                                <input name="filter" value="1" type="hidden">
                                                <button type="submit" class="btn btn-primary" style="margin-right:10px" >Seach Orders</button>
                                                
                                                
                                            </div>
                                            
                                        </div>
                                    </form>
                                   
                                </div>
                            </div>
                            
                            
                            <form action="<?=base_url();?>admin/orders/changestatus" method="post">
                            <? if($this->input->post()){ ?>
                            <div class="row">
                                <div class="row" style="margin-bottom:10px">
                                    <div class="col-12">
                                    </div>
                                    
                                    <div class="col-12">
                                        <?php if(count($orders) < 1 && isset($_POST['filter'])){ ?>
                                            <br>
                                            <div class="alert alert-danger">Order list is empty.</div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                            <!-- end page title --> 
                            <?php } ?>
                            <?php 
                            if($this->input->post()){
                            if(count($orders) > 0){ ?>
                           
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="card">
                                        
                                        <div class="card-body">
                                        <div class="card-title" style="font-size: 20px;">Orders</div>
                                           <table  class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th width="15%">Date/Time</th>
                                                                        <th >Order#</th>
                                                                        <th >Buyer</th>
                                                                        <th >Total Amount</th>
                                                                        <th >Payment Method</th>
                                                                        <th >Status</th>
                                                                        <th >Action</th>
                                                                    </tr>
                                                                </thead>
                                                            
                                                            
                                                                <tbody>
                                                                    <?php 
                                                                    $sn = 0;
                                                                    foreach($orders as $order){
                                                                        $user = $this->db->select("*")->from("app_users")->where('id', $order['user_id'])->get()->row_array();
                                                                        // $order = $this->db->select("*")->from("app_orders")->where('id', $ordedt['order_id'])->get()->row_array();
                                                                    $sn++ ;?>
                                                                    <tr>
                                                                        <td><?=date('d/M H:i', strtotime($order['created_date']));?></td>
                                                                        <td><?=$order['id'];?></td>
                                                                        <td><?=$user['full_name'];?><br><?=$user['email'];?></td>
                                                                        <td><?=$order['total_amount'];?></td>
                                                                        <td><?if($order['payment_method']==1){echo'Cash on Delivery';}elseif($order['payment_method']==2){echo'Credit Card';}elseif($order['payment_method']==3){echo'Paypal';}?></td>
                                                                        <td><?php if($order['status'] == 0){ ?>
                                                                        <span class="badge bg-danger" style="float:right">Pending/New Order</span>
                                                                        <?php }elseif($order['status'] == 1){ ?>
                                                                        <span class="badge bg-warning" style="float:right">In Prepration</span>
                                                                        <?php }elseif($order['status'] == 2){ ?>
                                                                        <span class="badge bg-primary" style="float:right">Out for Delivery</span>
                                                                        <?php }elseif($order['status'] == 100){ ?>
                                                                        <span class="badge bg-success" style="float:right">Delivered/Completed</span>
                                                                        <?php }elseif($order['status'] == 11){ ?>
                                                                        <span class="badge bg-secondary" style="float:right">Return for refund</span>
                                                                        <?php }elseif($order['status'] == 12){ ?>
                                                                        <span class="badge bg-secondary" style="float:right">Not Delivered</span>
                                                                        <?php }elseif($order['status'] == 13){ ?>
                                                                        <span class="badge bg-secondary" style="float:right">Cancelled by Customer</span>
                                                                        <?php }elseif($order['status'] == 14){ ?>
                                                                        <span class="badge bg-secondary" style="float:right">Out of Stock</span>
                                                                        <?php }elseif($order['status'] == 15){ ?>
                                                                        <span class="badge bg-secondary" style="float:right">Lost/Stolen</span>
                                                                        <?php } ?></td>
                                                                        <td>
                                                                            
                                                                            <a  href="<?=base_url();?>admin/orders/view/<?=$order['id'];?>" class="btn btn-success btn-xs waves-effect waves-light">View</a>
                                                                        </td>
                                                                    </tr>
                                                                    <?php } ?>
                                                                </tbody>
                                                            </table>
                                            <!-- end accordion -->
                                        </div>
                                        <!-- end card body -->
                                    </div>
                                    <!-- end card -->
                                </div> <!-- end col -->
                            </div> <!-- end row --> 
                            <?php }} ?>
                            
                        </form>
                    </div> <!-- container -->

                </div> <!-- content -->

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <?="&copy; 2014-".date('Y')." Ali Softtech. All Right Reserved"?> 
                            </div>
                            <div class="col-md-6">
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>